<?php
$con=mysqli_connect("localhost",'root','','trf_proj');


    ?>