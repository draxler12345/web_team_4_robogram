<?php 
include('db.php');
    if(isset($_POST['submit']))
    {
        $email =$_POST['email'];
        $uname =$_POST['Username'];
        $password = $_POST['pwd'];
        $name = $_POST['name'];

        $query = "INSERT INTO `registration`(`Name`,`User name`,`email`,`Password`) VALUES ('$name','$uname','$email','$password')";
        $run = mysqli_query($con,$query);
        if($run)
        {
            echo "Signed up successfully...";
        }
        else
        {
            echo "Not Inserted";
            echo mysqli_error($con);
        }
    
        header("Location:loginn.html");
        exit;
    }
    ?>
    