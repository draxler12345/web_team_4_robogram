<html lang = "en"> 
<head>
    <meta charset = "UTF-8">
    <title>Home Page</title>


    <link rel="stylesheet" href="page.css">
    
    
</head>
<body>
    <div class="split1">
        <h1 class="m">Robogram</h1>
    <header>Welcome to RoboGram !</header>
    <form method = "POST"  class = "home-page">  
    <div class = "input">
        <input type = "text" class="text" name ="text" placeholder = "Enter Text you want to POST">

    </div>
    <input type="submit" value="Post"  name="post" class="submit-btn"/>
    </form>

    
</div>



<?php
include('db.php');
session_start();
if(isset($_POST['post']))

{
    $post=$_POST['text'];
   
    $query="INSERT INTO `posts`(`User name`, `Posts`) VALUES('".$_SESSION['uname']."','$post')";
    $run=mysqli_query($con,$query);
    if(!$run)
    {
        echo "not inserted";
        echo mysqli_error($con);
    }
   
}
?>

 <div class="split2">
    <?php
include('db.php');
$query1 = "SELECT * FROM `posts`";
$run1=mysqli_query($con,$query1);
if($run1)
    {
       
       while( $user_row=mysqli_fetch_assoc($run1)){
           $a[]=$user_row;
       }
      $a=array_reverse($a,true);
      $i=0;
      foreach($a as $b){
          if ($i==20){
          break;
          }
          else{?>
       <h3><?php echo $b['User name'].": ".$b['Posts']."<br>"?></h3>
       <hr>
             <?php  $i=$i+1;}
      }
       
        
        
    }
    if(isset($_GET['follow']))
     
     { 
         $friend1 = $_GET['follow'];
        $friend2 = $_SESSION['uname'];
        echo $friend2;
        echo $friend1;
        $query2="INSERT INTO `friend_request`(`frnd1`,`frnd2`)VALUES('$friend1','$friend2')";
        $run2=mysqli_query($con,$query2);
        if($run2){
            echo "success";
        }
        else{
            echo "error";
        }
     }
    ?>
    </div>
    <div class="split3">
    <form method="GET" action="" name="login">
    <table class="table table-borderless" >
      <thead>
         <tr> <th scope="col"><h1>All users</h1></th></tr>
      </thead>
      <tbody>
          <?php
          include('db.php');
          
          $query3 = "SELECT * FROM `registration`";
          $run3=mysqli_query($con,$query3);
            while($row=mysqli_fetch_assoc($run3)){
          ?>
        <tr>
           <th><label><h2><?php echo $row['User name']; ?></h2> </label></th>
           <th><h2><a href="?follow=<?php echo $row['User name']; ?>" >Follow</a></h2></th>
       </tr>
     
     <?php
            }
    
      
     ?>
     </form>
    </tbody>
   </table>
    </div>
    </body>
    </html>