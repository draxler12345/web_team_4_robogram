<?php
include('db.php');
session_start();
if(isset($_POST['login']))
{
    
    $_SESSION['uname']=$_POST['username'];
    $password=$_POST['password'];
    $query = "SELECT * FROM `registration` WHERE `User name`='".$_SESSION['uname']."' AND `Password`='$password'";
    $run=mysqli_query($con,$query);
    $row=mysqli_num_rows($run);
    if($row==1)
    {
        header("Location:page.php");
        exit;
    }
    else
    {
        echo "Wrong Username or Password";
    }
}
?>